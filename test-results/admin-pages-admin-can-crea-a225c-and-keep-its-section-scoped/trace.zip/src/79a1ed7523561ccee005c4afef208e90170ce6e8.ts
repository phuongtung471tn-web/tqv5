import { expect, test } from "@playwright/test";

test("admin can create a secondary page and keep its section scoped", async ({
  page,
}) => {
  await page.goto("/admin");
  await page.getByPlaceholder("Mật khẩu quản trị").fill("duhoc2026");
  await page.getByRole("button", { name: "Đăng nhập" }).click();

  await expect(page).toHaveURL(/\/$/);
  await expect(page.getByRole("button", { name: "Đa Trang" })).toBeVisible();
  await page.getByRole("button", { name: "Đa Trang" }).click();
  await expect(
    page.getByRole("heading", { name: "Quản Lý Đa Trang & Menu" }),
  ).toBeVisible();

  await page.getByRole("button", { name: "+ Trang mới" }).click();
  await page.getByLabel("Tên trang").fill("Trang phụ kiểm thử");
  await page.getByLabel("Tiêu đề hiển thị").fill("Trang phụ kiểm thử");
  await page.getByRole("button", { name: /\+ Hero/ }).click();
  await page
    .getByLabel("Tiêu đề", { exact: true })
    .last()
    .fill("Block chỉ dành cho trang phụ");

  const pagePath = await page.getByLabel("Đường dẫn").inputValue();
  await page.getByRole("button", { name: "Đóng" }).click();

  const secondaryPageLink = page.getByRole("link", {
    name: "Trang phụ kiểm thử",
  });
  await expect(secondaryPageLink).toHaveAttribute("href", `/${pagePath}`);
  await secondaryPageLink.click();
  await expect(page).toHaveURL(new RegExp(`/${pagePath}$`));
  await expect(
    page.getByRole("heading", { name: "Block chỉ dành cho trang phụ" }),
  ).toBeVisible();

  await page.goto("/");
  await expect(
    page.getByRole("heading", { name: "Block chỉ dành cho trang phụ" }),
  ).toHaveCount(0);
});

test("admin guide health modal shows readiness summary and checklist", async ({
  page,
}) => {
  await page.goto("/admin");
  await page.getByPlaceholder("Mật khẩu quản trị").fill("duhoc2026");
  await page.getByRole("button", { name: "Đăng nhập" }).click();

  await expect(page).toHaveURL(/\/$/);
  await page.getByRole("button", { name: "Hướng Dẫn & Health" }).click();

  await expect(
    page.getByRole("heading", { name: "Hướng Dẫn & Health Check" }),
  ).toBeVisible();
  await expect(page.getByText("Điểm health")).toBeVisible();
  await expect(
    page.getByText("Tính năng này sinh ra để làm gì?"),
  ).toBeVisible();
  await expect(
    page.getByText("Checklist giá trị sau khi hoàn tất"),
  ).toBeVisible();
  await expect(
    page.getByText("Nâng cấp đề xuất:", { exact: false }),
  ).toHaveCount(8);
});
